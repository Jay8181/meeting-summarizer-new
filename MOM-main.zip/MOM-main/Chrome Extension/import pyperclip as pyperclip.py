import pyperclip as pc
text = pc.paste()

print(text)
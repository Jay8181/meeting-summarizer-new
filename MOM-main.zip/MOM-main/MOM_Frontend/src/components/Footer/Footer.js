import React from 'react'
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../../../node_modules/font-awesome/css/font-awesome.min.css'
import { NavLink } from 'react-router-dom'
import './style.css'
function footer() {
    return (
        <div>
            
<footer className="page-footer middleColor  font-small unique-color-dark">

  <div className="footer-copyright text-center py-3 copyrightColor white">
    Copyright © 2021 Meet Digest
  </div>

</footer>
</div>
        
    )
}

export default footer
